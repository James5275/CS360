package com.cs360.jamesehrleweighttracker;

public class Users {
    private String Name;
    private String Username;
    private String Password;
    private long uId;
    public Users(String username) {
        Username = username;
    }

    public Users(String name, String username, String password) {
        Name = name;
        Username = username;
        Password = password;
    }


    public String getName() {
        return Name;
    }
    public void setName(String name) {
        Name = name;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public long getuId() {
        return uId;
    }

    public void setuId(long uId) {
        this.uId = uId;
    }
}
