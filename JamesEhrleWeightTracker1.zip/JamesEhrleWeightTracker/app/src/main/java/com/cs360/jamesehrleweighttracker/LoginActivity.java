package com.cs360.jamesehrleweighttracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;


public class LoginActivity extends AppCompatActivity {
    UserDatabase user_database;
    private EditText mUserName;
    private EditText mPassword;
    private Button mLoginButton;
    Users users;
    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            //Checking if UserName and Password fields are empty
            mLoginButton.setEnabled(!mUserName.getText().toString().isEmpty() && !mPassword.getText().toString().isEmpty());
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        //Creating SMS request permission
        int pl = ActivityCompat.checkSelfPermission(LoginActivity.this, Manifest.permission.SEND_SMS);
        if (pl != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(LoginActivity.this, new String[] {Manifest.permission.SEND_SMS}, 100);
        }
        else {
            accessApp();
        }


        //Assign the widgets to fields
        mUserName = findViewById(R.id.username_EditText);
        mPassword = findViewById(R.id.password_EditText);
        mLoginButton = findViewById(R.id.login_button);
        user_database = new UserDatabase(this);

        //Setting Button to "false"
        mLoginButton.setEnabled(false);

        //Add Text Changed Listener to username and password
        mUserName.addTextChangedListener(textWatcher);
        mPassword.addTextChangedListener(textWatcher);

    }
    //SMS request if denied and if granted
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults, int deviceId) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults, deviceId);
        if (requestCode == 100 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            accessApp();
        else if (requestCode == 100 && grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
        }
    }

    private void accessApp() {
        Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
    }

    public void onLoginClick(View view){
        String user, pass;
        user = mUserName.getText().toString();
        pass = mPassword.getText().toString();

        boolean loginSuccess = user_database.verifyUser(user, pass);
        if (loginSuccess) {
            Toast.makeText(LoginActivity.this, "Welcome " + user_database.getName(user) , Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(LoginActivity.this, dataHome.class);
            startActivity(intent);
        }
        else {
            Toast.makeText(LoginActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
        }
    }

    public void onRegisterClick(View view){
        Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
        startActivity(intent);
    }

}