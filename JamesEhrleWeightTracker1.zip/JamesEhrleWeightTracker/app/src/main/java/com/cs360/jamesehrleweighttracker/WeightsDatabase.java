package com.cs360.jamesehrleweighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WeightsDatabase extends SQLiteOpenHelper {
    private static WeightsDatabase weightsDatabase;
    private static final String DATABASE_NAME = "weights.db";
    private static final int VERSION = 8;
    private static final String TABLE_NAME = "weights_table";





    private static final String COL_ID = "id";
    private static final String COL_WEIGHT = "weight";
    private static final String COL_DATE = "date";


    public WeightsDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    public static WeightsDatabase instanceOfDatabase(Context context) {
        if(weightsDatabase == null)
            weightsDatabase = new WeightsDatabase(context);

        return weightsDatabase;
    }


    @Override
    public void onCreate(SQLiteDatabase database) {
        database.execSQL("create table " + TABLE_NAME + " (" +
                COL_ID + " integer primary key autoincrement, " +
                COL_WEIGHT + " text, " +
                COL_DATE + " text )");
    }

    @Override
    public void onUpgrade(SQLiteDatabase database, int oldVersion, int newVersion) {
        database.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(database);
    }

    public void addWeight(DailyWeight dailyWeight) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_ID, dailyWeight.getId());
        values.put(COL_WEIGHT, dailyWeight.getWeight());
        values.put(COL_DATE, dailyWeight.getDate());

        database.insert(TABLE_NAME, null, values);
        database.close();
    }

    public void populateWeightListArray() {
        SQLiteDatabase database = this.getReadableDatabase();
        try (Cursor result = database.rawQuery("SELECT * FROM " + TABLE_NAME, null)) {
            if (result.getCount() != 0) {
                while (result.moveToNext()) {
                    int id = result.getInt(0);
                    String weight = result.getString(1);
                    String date = result.getString(2);
                    DailyWeight dailyWeight = new DailyWeight(id,weight,date);
                    DailyWeight.weightArrayList.add(dailyWeight);
                }
            }
        }
    }

    public void updateWeight(DailyWeight dailyWeight) {

        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues ();

        values.put(COL_ID, dailyWeight.getId());
        values.put(COL_WEIGHT, dailyWeight.getWeight()) ;
        values.put(COL_DATE, dailyWeight.getDate());

        database.update(TABLE_NAME, values, COL_ID + " = ? ", new String[]{String.valueOf(dailyWeight.getId())});

    }

    public void deleteWeight(DailyWeight dailyWeight) {
        SQLiteDatabase database = this.getWritableDatabase();
        database.delete(TABLE_NAME, COL_ID + " = ?", new String[] {String.valueOf(dailyWeight.getId())});
    }
}
