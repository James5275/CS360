package com.cs360.jamesehrleweighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    private EditText rUserName, rPassword, rName, rGoalWeight;
    private Button rSignUp, rCancel;
    UserDatabase user_database;

    private final TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            //Checking if UserName and Password fields are empty
            rSignUp.setEnabled(!rUserName.getText().toString().isEmpty()
                    && !rPassword.getText().toString().isEmpty() && !rName.getText().toString().isEmpty() && !rGoalWeight.getText().toString().isEmpty());
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);

        //Initialize register variables
        rUserName = findViewById(R.id.username_register);
        rPassword =findViewById(R.id.password_register);
        rName = findViewById(R.id.name_register);
        rGoalWeight = findViewById(R.id.goalWeight_register);
        rSignUp = findViewById(R.id.signUp_button);
        user_database = new UserDatabase(this);


        //Set Button to false
        rSignUp.setEnabled(false);

        //Add Text watcher
        rUserName.addTextChangedListener(textWatcher);
        rPassword.addTextChangedListener(textWatcher);
        rName.addTextChangedListener(textWatcher);
        rGoalWeight.addTextChangedListener(textWatcher);
    }
    public void onCancel(View view){
        Toast.makeText(RegisterActivity.this, "Going back to login", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
        startActivity(intent);
    }

    public void SignUpButton(View view) {
        String user, pass, name, goal;

        user = rUserName.getText().toString();
        pass = rUserName.getText().toString();
        name = rName.getText().toString();

        Users nUser = new Users(name, user, pass);

        if(user_database.checkUserName(user)) {
            Toast.makeText(RegisterActivity.this, "Username Already Exists", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
            startActivity(intent);
        }

        else {

            boolean regSuccess = user_database.addUser(nUser);

            if (regSuccess) {
                Toast.makeText(RegisterActivity.this, "User Successfully Signed up", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(RegisterActivity.this, dataHome.class);
                startActivity(intent);
            }
            else {
                Toast.makeText(RegisterActivity.this, "Sign up Error", Toast.LENGTH_SHORT).show();
            }
        }

    }
}