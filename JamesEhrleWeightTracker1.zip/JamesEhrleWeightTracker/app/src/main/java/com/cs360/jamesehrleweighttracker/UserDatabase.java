package com.cs360.jamesehrleweighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class UserDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "users.db";
    private static final int VERSION = 4;
    public static UserDatabase userdata;

    public static UserDatabase getInstance(Context context) {
        if(userdata == null) {
            userdata = new UserDatabase(context);
        }
        return userdata;
    }
    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null , VERSION);
    }


    private static final String TABLE = "users";
    private static final String COL_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";
    private static final String COL_NAME = "name";



    @Override
    public void onCreate(SQLiteDatabase db) {
        //USER TABLE
        db.execSQL("create table " + TABLE + " (" +
                COL_ID + " integer primary key autoincrement, " +
                COL_USERNAME + " text, " +
                COL_PASSWORD + " text, " +
                COL_NAME + " text )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + TABLE);
        onCreate(db);
    }

    //Adding user to the userDB
    public boolean addUser(Users users) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, users.getUsername());
        values.put(COL_PASSWORD, users.getPassword());
        values.put(COL_NAME, users.getName());

        long id = db.insert(TABLE, null, values);
        users.setuId(id);
        return id != -1;
    }

    //USER DATABASE
    public boolean checkUserName(String username) {
        SQLiteDatabase db = getWritableDatabase();
        String sql = "select * from " + TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { username });
        return cursor.getCount() > 0;
    }

    //USER DATABASE
    public boolean verifyUser(String username, String password) {
        SQLiteDatabase db = getWritableDatabase();
        String sql = "select * from " + TABLE + " where username = ? and password = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { username, password });
        return cursor.getCount() > 0;
    }

    //USER DATABASE
    public String getName(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String name = "Name not found";
        String sql = "select * from " + TABLE + " where username = ?";
        Cursor cursor = db.rawQuery(sql, new String[] {username});

        if (cursor.moveToFirst()) {
            int nameColumnIndex = cursor.getColumnIndex(COL_NAME);
            if (nameColumnIndex != -1) {
                name = cursor.getString(nameColumnIndex);
            }
        }
        return name;
    }
}
