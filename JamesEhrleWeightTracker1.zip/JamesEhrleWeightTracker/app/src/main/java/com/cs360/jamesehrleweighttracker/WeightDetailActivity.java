package com.cs360.jamesehrleweighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.sql.Date;

public class WeightDetailActivity extends AppCompatActivity {
    private EditText weightEditText, dateEditText;
    private DailyWeight selectedWeight;
    private Button deleteButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_weight_detail);

        weightEditText = findViewById(R.id.weightEditText);
        dateEditText = findViewById(R.id.dateEditText);
        deleteButton = findViewById(R.id.deleteWeightButton);

        checkForEditWeights();
    }


    private void checkForEditWeights() {
        Intent previousIntent = getIntent();
        int passedWeightID = previousIntent.getIntExtra(DailyWeight.WEIGHT_EDIT_EXTRA, -1);
        selectedWeight = DailyWeight.getWeightForID(passedWeightID);

        if (selectedWeight != null) {
            weightEditText.setText(selectedWeight.getWeight());
            dateEditText.setText(selectedWeight.getDate());
        }
        else {
            deleteButton.setVisibility(View.INVISIBLE);
        }
    }
    public void saveWeight(View view){
        WeightsDatabase weightsDatabase = WeightsDatabase.instanceOfDatabase(this);

        String weight = String.valueOf(weightEditText.getText() + " lbs");
        String date = String.valueOf(dateEditText.getText());

        if(selectedWeight == null) {
            int id = DailyWeight.weightArrayList.size();
            DailyWeight newDailyWeight = new DailyWeight(id, weight, date);
            DailyWeight.weightArrayList.add(newDailyWeight);
            weightsDatabase.addWeight(newDailyWeight);

        }
        else {
            selectedWeight.setWeight(weight);
            selectedWeight.setDate(date);
            weightsDatabase.updateWeight(selectedWeight);
        }
        finish();
    }

    public void detailBack(View view){
        Intent newDailyIntent = new Intent(this, dataHome.class);
        startActivity(newDailyIntent);
    }

    public void deleteWeight(View view) {
        WeightsDatabase weightsDatabase = WeightsDatabase.instanceOfDatabase(this);
        DailyWeight.weightArrayList.remove(selectedWeight);
        weightsDatabase.deleteWeight(selectedWeight);

        Intent newDailyIntent = new Intent(this, dataHome.class);
        startActivity(newDailyIntent);

    }
}