package com.cs360.jamesehrleweighttracker;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class dataHome extends AppCompatActivity {
    private ListView weightListView;
    TextView mGoalWeight;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_data_home);
        mGoalWeight = findViewById(R.id.goalTextView);
        mGoalWeight.setText("235");
        weightListView = findViewById(R.id.weightListView);
        
        loadFromDBToMemory();
        setWeightAdapter();
        setOnClickListener();
    }

    private void loadFromDBToMemory() {
        WeightsDatabase weightsDatabase = WeightsDatabase.instanceOfDatabase(this);
        weightsDatabase.populateWeightListArray();
    }

    private void setWeightAdapter() {
        DailyAdapter dailyAdapter = new DailyAdapter(getApplicationContext(), DailyWeight.weightArrayList);
        weightListView.setAdapter(dailyAdapter);
    }

    private void setOnClickListener() {
        weightListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                DailyWeight selectedWeight = (DailyWeight) weightListView.getItemAtPosition(position);

                Intent editWeightIntent = new Intent(getApplicationContext(), WeightDetailActivity.class);
                editWeightIntent.putExtra(DailyWeight.WEIGHT_EDIT_EXTRA, selectedWeight.getId());
                startActivity(editWeightIntent);
            }
        });
    }
    public void newDailyWeight(View view) {
        Intent newDailyIntent = new Intent(this, WeightDetailActivity.class);
        startActivity(newDailyIntent);
    }

    protected void onResume() {
        super.onResume();
        setWeightAdapter();
    }
    public void logOut(View view) {
        Intent intent = new Intent(dataHome.this, LoginActivity.class);
        startActivity(intent);
    }

    public void onAddClick(View view) {
        Intent intent = new Intent(dataHome.this, WeightDetailActivity.class);
        startActivity(intent);
    }


}