package com.cs360.jamesehrleweighttracker;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class DailyAdapter extends ArrayAdapter<DailyWeight> {

    public DailyAdapter(Context context, List<DailyWeight> weights) {
        super(context, 0, weights);
    }
    //creating the list view adding the weights and dates
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        DailyWeight dailyWeight = getItem(position);
        //if null show none
        if(convertView == null)
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.daily_cell, parent, false);

        TextView weight = convertView.findViewById(R.id.cellWeight);
        TextView date = convertView.findViewById(R.id.cellDate);

        // if not null seet the tesx for the weight and date
        assert dailyWeight != null;
        weight.setText(dailyWeight.getWeight());
        date.setText(dailyWeight.getDate());

        return convertView;
    }
}
