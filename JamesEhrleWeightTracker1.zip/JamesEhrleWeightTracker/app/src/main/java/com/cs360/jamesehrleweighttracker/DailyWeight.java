package com.cs360.jamesehrleweighttracker;

import java.util.ArrayList;
import java.util.Date;

public class DailyWeight {

    public static ArrayList<DailyWeight> weightArrayList = new ArrayList<>();
    public static String WEIGHT_EDIT_EXTRA = "weightEdit";
    private int id;
    private String weight;
    private String  Date;

    public DailyWeight(String weight, String date) {
        this.weight = weight;
        Date = date;
    }

    public DailyWeight(int id, String weight, String date) {
        this.id = id;
        this.weight = weight;
        Date = date;
    }

    public static DailyWeight getWeightForID(int passedWeightID) {
        for (DailyWeight dailyWeight : weightArrayList) {
            if(dailyWeight.getId() == passedWeightID)
                return dailyWeight;
        }

        return null;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }
}
